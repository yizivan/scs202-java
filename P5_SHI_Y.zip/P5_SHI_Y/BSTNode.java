package P5_SHI_Y;
public class BSTNode<T> extends BTNode<T>
{
    public BSTNode(T info) 
    {
        super(info);
    }
    
}